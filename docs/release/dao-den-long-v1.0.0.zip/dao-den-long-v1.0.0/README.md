# Đảo Đèn Lồng · v1.0.0

Cần macOS hoặc Linux, Node 22.12+ và trình duyệt hỗ trợ WebGL 2.
Tại thư mục giải nén, chạy:

```sh
node scripts/run.mjs
```

Mở địa chỉ localhost được in ra nếu trình duyệt chưa tự mở.
WASD đi, Space nhảy, Shift lướt, E nạp đèn, Q tỏa sáng, Esc tạm dừng.
Có thể đổi phím trong Cài đặt.

Xuất bảng điểm từ tệp lưu của launcher:

```sh
node scripts/run.mjs --export-leaderboard out.json
```
